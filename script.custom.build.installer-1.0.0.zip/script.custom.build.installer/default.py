import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import shutil
from urllib.request import urlopen
import zipfile

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
KODI_HOME = xbmcvfs.translatePath("special://home")
TEMP_ZIP = xbmcvfs.translatePath("special://temp/ashcan_build.zip")
TEMP_EXTRACT = xbmcvfs.translatePath("special://temp/ashcan_build/")

# CHANGE THIS TO YOUR REAL BUILD ZIP URL
BUILD_URL = "https://www.dropbox.com/scl/fi/glc4wagx7mmdvso88jmiu/encore.zip?rlkey=836o6k19xlppx2ab9ek0zvcbt&dl=1"


# ==================================================================
#  FIRESTICK-SAFE FRESH INSTALL (DOES NOT DELETE SYSTEM ADDONS)
# ==================================================================
def fresh_install():
    if not xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Fresh install full build?\n\nThis will erase your Kodi data except system addons."
    ):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Preparing install...")

    try:
        # ----------------------------------------------------------
        # 0–30%  DOWNLOAD THE BUILD ZIP
        # ----------------------------------------------------------
        progress.update(0, "Downloading build...")
        resp = urlopen(BUILD_URL)
        total = int(resp.headers.get("content-length", 0)) or 1
        down = 0
        chunk = 1024 * 1024

        with open(TEMP_ZIP, "wb") as f:
            while True:
                if progress.iscanceled():
                    raise Exception("Cancelled")
                data = resp.read(chunk)
                if not data:
                    break
                f.write(data)
                down += len(data)
                pct = int((down / total) * 30)
                progress.update(pct, f"Downloading... {down//(1024*1024)} MB")

        # ----------------------------------------------------------
        # 30–60%  EXTRACT ZIP TO TEMP
        # ----------------------------------------------------------
        progress.update(30, "Extracting build...")
        with zipfile.ZipFile(TEMP_ZIP, "r") as z:
            files = z.namelist()
            total_files = len(files)

            for i, f in enumerate(files):
                if progress.iscanceled():
                    raise Exception("Cancelled")
                z.extract(f, TEMP_EXTRACT)
                pct = 30 + int((i + 1) * 30 / total_files)
                progress.update(pct, f"Extracting... {i+1}/{total_files}")

        # ----------------------------------------------------------
        # 60–90%  COPY USERDATA + ADDONS (SAFE MODE)
        # ----------------------------------------------------------
        progress.update(60, "Installing userdata and addons...")

        def safe_copytree(src, dst, start_pct=60, end_pct=90):
            """Firestick-safe version — only overwrites YOUR addons, not system addons."""
            all_files = []

            for root, dirs, files in os.walk(src):
                for f in files:
                    all_files.append(os.path.join(root, f))

            total_files = len(all_files)
            done = 0

            for root, dirs, files in os.walk(src):
                for f in files:
                    s = os.path.join(root, f)
                    d = os.path.join(dst, os.path.relpath(s, src))

                    os.makedirs(os.path.dirname(d), exist_ok=True)

                    shutil.copy2(s, d)
                    done += 1

                    pct = start_pct + int(done * (end_pct - start_pct) / total_files)
                    progress.update(pct, f"Installing... {done}/{total_files}")

        # ---- USERDATA safe copy ----
        ud_src = os.path.join(TEMP_EXTRACT, "userdata")
        ud_dst = os.path.join(KODI_HOME, "userdata")

        if os.path.exists(ud_src):
            shutil.rmtree(ud_dst, ignore_errors=True)
            safe_copytree(ud_src, ud_dst, 60, 75)

        # ---- ADDONS safe copy (does NOT delete system addons) ----
        ad_src = os.path.join(TEMP_EXTRACT, "addons")
        ad_dst = os.path.join(KODI_HOME, "addons")

        if os.path.exists(ad_src):
            for item in os.listdir(ad_src):
                s = os.path.join(ad_src, item)
                d = os.path.join(ad_dst, item)

                # Only remove your own addons
                if os.path.exists(d):
                    shutil.rmtree(d, ignore_errors=True)

                # Copy only your addon folders — leaves system addons alone
                safe_copytree(s, d, 75, 90)

        # ----------------------------------------------------------
        # 90–100%  CLEANUP
        # ----------------------------------------------------------
        progress.update(90, "Cleaning up...")
        if os.path.exists(TEMP_EXTRACT):
            shutil.rmtree(TEMP_EXTRACT, ignore_errors=True)
        if os.path.exists(TEMP_ZIP):
            os.remove(TEMP_ZIP)

        progress.update(100, "Install complete!")
        progress.close()

        xbmcgui.Dialog().ok(ADDON_NAME, "Build installed!\nKodi will restart now.")
        xbmc.executebuiltin("RestartApp")

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok("Error", str(e))



# ==================================================================
#  FIRESTICK-SAFE REDUCE BUILD SIZE (PROGRESS BAR)
# ==================================================================
def reduce_build_size_progress():
    import time

    KODI = KODI_HOME
    progress = xbmcgui.DialogProgress()
    progress.create("Ashcan57 Wizard", "Reducing Build Size...")

    total_freed = 0

    def get_size(path):
        size = 0
        if os.path.isfile(path):
            try:
                size = os.path.getsize(path)
            except:
                pass
        else:
            for root, dirs, files in os.walk(path):
                for f in files:
                    try:
                        size += os.path.getsize(os.path.join(root, f))
                    except:
                        pass
        return size

    # 0–25% THUMBNAILS
    progress.update(0, "Cleaning thumbnails...")
    thumbs = os.path.join(KODI, "userdata", "Thumbnails")
    if os.path.exists(thumbs):
        total_freed += get_size(thumbs)
        shutil.rmtree(thumbs, ignore_errors=True)
    progress.update(25, "Thumbnails cleaned")

    # 25–50% TEXTURE DATABASES
    progress.update(25, "Cleaning texture cache...")
    db_folder = os.path.join(KODI, "userdata", "Database")
    texture_dbs = [
        "Textures13.db", "Textures14.db", "Textures15.db",
        "Textures16.db", "Textures20.db"
    ]
    for i, db in enumerate(texture_dbs):
        f = os.path.join(db_folder, db)
        if os.path.exists(f):
            total_freed += get_size(f)
            try:
                os.remove(f)
            except:
                pass
        pct = 25 + int((i + 1) * 25 / len(texture_dbs))
        progress.update(pct, f"Removing {db}...")

    # 50–75% ADDON PACKAGES
    progress.update(50, "Cleaning addon packages...")
    packages = os.path.join(KODI, "addons", "packages")
    if os.path.exists(packages):
        total_freed += get_size(packages)
        shutil.rmtree(packages, ignore_errors=True)
    progress.update(75, "Packages cleaned")

    # 75–100% TEMP FILES
    progress.update(75, "Cleaning temp files...")
    temp_path = os.path.join(KODI, "userdata", "temp")
    if os.path.exists(temp_path):
        total_freed += get_size(temp_path)
        shutil.rmtree(temp_path, ignore_errors=True)
    progress.update(100, "Cleanup complete!")
    progress.close()

    mb = round(total_freed / (1024 * 1024), 1)
    xbmcgui.Dialog().ok("Ashcan57 Wizard", f"Size reduction complete!\nFreed approx: {mb} MB")



# ==================================================================
#  BASIC UTILITIES
# ==================================================================
def clear_cache():
    shutil.rmtree(os.path.join(KODI_HOME, "userdata", "cache"), ignore_errors=True)
    xbmcgui.Dialog().ok(ADDON_NAME, "Cache cleared")

def clear_thumbnails():
    shutil.rmtree(os.path.join(KODI_HOME, "userdata", "Thumbnails"), ignore_errors=True)
    xbmcgui.Dialog().ok(ADDON_NAME, "Thumbnails cleared")

def clear_packages():
    shutil.rmtree(os.path.join(KODI_HOME, "addons", "packages"), ignore_errors=True)
    xbmcgui.Dialog().ok(ADDON_NAME, "Packages cleared")

def force_close():
    xbmc.executebuiltin("Quit")


# ==================================================================
#  MAIN MENU
# ==================================================================
def main_menu():
    items = [
        ("Fresh Install Build (Firestick Safe)", fresh_install),
        ("Reduce Build Size (Progress Bar)", reduce_build_size_progress),
        ("Clear Cache", clear_cache),
        ("Clear Thumbnails", clear_thumbnails),
        ("Clear Packages", clear_packages),
        ("Force Close Kodi", force_close),
    ]

    while True:
        choice = xbmcgui.Dialog().select("Ashcan57 Wizard", [i[0] for i in items])
        if choice < 0:
            break
        items[choice][1]()


if __name__ == "__main__":
    main_menu()
